<?php

class ffAdminScreenGeneralOptionsViewDefault extends ffAdminScreenView {

	public function actionSave( ffRequest $request ) {
	}
	
	protected function _render() {
	}

	protected function _requireAssets() {
	}

	protected function _setDependencies() {
	}

	public function ajaxRequest( ffAdminScreenAjax $ajax ) {
	}
}