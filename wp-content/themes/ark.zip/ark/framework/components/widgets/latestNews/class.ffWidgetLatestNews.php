<?php

class ffWidgetLatestNews extends ffWidgetDecoratorAbstract {
	protected $_widgetAdminTitle =       'Latest News - Custom Widget';
	protected $_widgetAdminDescription = 'Displays your posts';
	protected $_widgetWrapperClasses =   '';
	protected $_widgetName = 'LatestNewsWidget';
    protected $_widgetAdditionalClasses = '';
}