<?php

class ffWidgetLatestPost extends ffWidgetDecoratorAbstract {
	protected $_widgetAdminTitle =       'Latest Post - Custom Widget';
	protected $_widgetAdminDescription = 'Displays image and link to page or post';
	protected $_widgetWrapperClasses =   '';
	protected $_widgetName = 'LatestPostWidget';
    protected $_widgetAdditionalClasses = '';
}