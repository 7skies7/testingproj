<?php

class ffWidgetTimeline extends ffWidgetDecoratorAbstract {
	protected $_widgetAdminTitle =       'Timeline - Custom Widget';
	protected $_widgetAdminDescription = 'Displays your posts';
	protected $_widgetWrapperClasses =   '';
	protected $_widgetName = 'TimelineWidget';
    protected $_widgetAdditionalClasses = '';
}