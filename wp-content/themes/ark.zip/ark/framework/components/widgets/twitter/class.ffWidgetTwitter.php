<?php

class ffWidgetTwitter extends ffWidgetDecoratorAbstract {
	protected $_widgetAdminTitle =       'Twitter - Custom Widget';
	protected $_widgetAdminDescription = 'Displays your latest tweets';
	protected $_widgetWrapperClasses =   '';
	protected $_widgetName = 'TwitterWidget';
	protected $_widgetAdditionalClasses = '';

}